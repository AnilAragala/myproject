import React from "react";
import "./Header.css";
import logo from "./images/abbott.png";

function Header() {
  return (
    <div className="header">
      <img className="header__logo" alt="abbott logo" src={logo} />
      <div className="header__option">
        <span className="header__optionLineThree">Server Manager</span>
      </div>
      <div className="header__nav">
        <div className="header__option">
          <span className="header__optionLineTwo">Requests</span>
        </div>
        <div className="header__option">
          <span className="header__optionLineTwo">Server Statistics</span>
        </div>
        <div className="header__option">
          <span className="header__optionLineTwo">Write Feedback</span>
        </div>
        <div className="header__option">
          <span className="header__optionLineTwo">Admin</span>
        </div>
        <div className="header__option">
          <span className="header__optionLineTwo">Operator Panel</span>
        </div>
        <div className="header__option">
          <span className="header__optionLineTwo">Logout | Abbott</span>
        </div>
      </div>
    </div>
  );
}

export default Header;
