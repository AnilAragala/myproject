import React from "react";
import "../components/Table.css";

const Posts = ({ posts, loading }) => {
  if (loading) {
    return <h2>Loading...</h2>;
  }
  function renderTableHeader() {
    let header = ["Server", "Date"];
    return header.map((val, index) => {
      return <th key={index}>{val}</th>;
    });
  }

  function renderTableData() {
    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
    var day = currentDate.getDate();
    var month = currentDate.getMonth() + 1;
    var year = currentDate.getFullYear();

    return posts.map((post, index) => {
      const { id, server } = post; //destructuring
      return (
        <tr key={id}>
          <td>{server}</td>
          <td>{day + "/" + month + "/" + year}</td>
        </tr>
      );
    });
  }

  return (
    <div>
      <h1 id="title">Upcoming Patches</h1>
      <table id="students">
        <tbody>
          <tr>{renderTableHeader()}</tr>
          {renderTableData()}
        </tbody>
      </table>
    </div>

    // <ul className="list-group mb-4">
    //   {posts.map((post) => (
    //     <li key={post.id} className="list-group-item">
    //       {post.title}
    //     </li>
    //   ))}
    // </ul>
  );
};

export default Posts;
