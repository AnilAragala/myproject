import React from "react";
import "../components/Table.css";

const Posts = ({ posts, loading }) => {
  if (loading) {
    return <h2>Loading...</h2>;
  }
  function renderTableHeader() {
    let header = [
      "Server",
      "Status",
      "Description",
      "Role",
      "Certification Date",
    ];
    return header.map((val, index) => {
      return <th key={index}>{val}</th>;
    });
  }

  function renderTableData() {
    return posts.map((post, index) => {
      const { id, server, description, role, certification_date } = post; //destructuring
      return (
        <tr key={id}>
          <td>{server}</td>
          <td>Active</td>
          <td>{description}</td>
          <td>{role}</td>
          <td>{certification_date}</td>
        </tr>
      );
    });
  }

  return (
    <div>
      <h1 id="title">My Resources</h1>
      <table id="students">
        <tbody>
          <tr>{renderTableHeader()}</tr>
          {renderTableData()}
        </tbody>
      </table>
    </div>

    // <ul className="list-group mb-4">
    //   {posts.map((post) => (
    //     <li key={post.id} className="list-group-item">
    //       {post.title}
    //     </li>
    //   ))}
    // </ul>
  );
};

export default Posts;
