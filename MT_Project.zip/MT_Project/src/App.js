import React, { useState, useEffect } from "react";
import Posts from "./components/Posts";
import Posts1 from "./components/Posts1";
import Pagination from "./components/Pagination";
import "./App.css";
import Header from "./components/Header";

const App = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(5);

  const [currentPatchPage, setCurrentPatchPage] = useState(1);
  // const [patchPerPage] = useState(5);
  const [patchData, setPatchData] = useState([]);

  const data_json = [
    {
      id: 1,
      server: "server1",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 2,
      server: "server2",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 3,
      server: "server3",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 4,
      server: "server4",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 5,
      server: "server5",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 6,
      server: "server6",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 7,
      server: "server7",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 8,
      server: "server8",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 9,
      server: "server9",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 10,
      server: "server10",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 11,
      server: "server11",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 12,
      server: "server12",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 13,
      server: "server13",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 14,
      server: "server14",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 15,
      server: "server15",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 16,
      server: "server16",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 17,
      server: "server17",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 18,
      server: "server18",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 19,
      server: "server19",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
    {
      id: 20,
      server: "server20",
      description: "testing ux screens",
      role: "admin",
      certification_date: "10 days remainig",
    },
  ];
  var currentDate = new Date();
  const patchingData = [
    {
      id: 1,
      server: "server1",
    },
    {
      id: 2,
      server: "server2",
    },
    {
      id: 3,
      server: "server3",
    },
    {
      id: 4,
      server: "server4",
    },
    {
      id: 5,
      server: "server5",
    },
    {
      id: 6,
      server: "server6",
    },
    {
      id: 7,
      server: "server7",
    },
    {
      id: 8,
      server: "server8",
    },
    {
      id: 9,
      server: "server9",
    },
    {
      id: 10,
      server: "server10",
    },
  ];

  useEffect(() => {
    const fetchPosts = () => {
      setLoading(true);
      setPosts(data_json);
      setPatchData(patchingData);
      setLoading(false);
    };

    fetchPosts();
  }, []);

  // Get current posts
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

  const indexOfLastPost1 = currentPatchPage * postsPerPage;
  const indexOfFirstPost1 = indexOfLastPost1 - postsPerPage;
  const currentPosts1 = patchData.slice(indexOfFirstPost1, indexOfLastPost1);

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  const paginate2 = (pageNumber) => setCurrentPatchPage(pageNumber);

  return (
    <>
      <Header />
      <div className="inline">
        <div className="one">
          <div>
            <Posts posts={currentPosts} loading={loading} />
            <br></br>
            <Pagination
              postsPerPage={postsPerPage}
              totalPosts={posts.length}
              paginate={paginate}
            />
          </div>
        </div>
        <div className="two">
          <div>
            <Posts1 posts={currentPosts1} loading={loading} />
            <br></br>
            <Pagination
              postsPerPage={postsPerPage}
              totalPosts={patchData.length}
              paginate={paginate2}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default App;
