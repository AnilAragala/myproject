# Simple React Pagination

> Frontend pagination example using React with Hooks

## Available Scripts

In the project directory, you can run:

### `npm install`

### `npm start`
